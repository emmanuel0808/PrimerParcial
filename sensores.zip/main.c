/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

 

#define MAX_SENSORES 5

 

// Definición de estructura para el sensor de freno
struct SensorFreno {
    int id;
    float presion;
    char ubicacion[20];
};

 

// Función para inicializar el arreglo de sensores de freno
void initializeSensores(struct SensorFreno* sensores) {
    for (int i = 0; i < MAX_SENSORES; i++) {
        printf("Ingrese el ID del sensor %d: ", i + 1);
        scanf("%d", &(sensores[i].id));

 

        printf("Ingrese la presión del sensor %d: ", i + 1);
        scanf("%f", &(sensores[i].presion));

 

        printf("Ingrese la ubicación del sensor %d: ", i + 1);
        scanf("%s", sensores[i].ubicacion);

 

        printf("\n");
    }
}

 

// Función para recorrer y mostrar los datos de cada sensor
void mostrarSensores(const struct SensorFreno* sensores) {
    for (int i = 0; i < MAX_SENSORES; i++) {
        printf("Sensor de freno ID: %d\n", sensores[i].id);
        printf("Presión del sensor: %.2f\n", sensores[i].presion);
        printf("Ubicación del sensor: %s\n", sensores[i].ubicacion);
        printf("\n");
    }
}

 

int main() {
    // Declaración del arreglo de sensores de freno
    struct SensorFreno sensores[MAX_SENSORES];

 

    // Inicializar el arreglo de sensores llamando a la función initializeSensores
    initializeSensores(sensores);

 

    // Mostrar los datos de cada sensor llamando a la función mostrarSensores
    mostrarSensores(sensores);
    
    return 0;
}