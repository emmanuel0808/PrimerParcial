/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

struct Persona{
    char nombre[50];
    int edad;
    float altura;
};


int main()
{
    struct Persona persona1;
    
    strcpy(persona1.nombre,"Pedro");
    persona1.edad=20;
    persona1.altura=1.70;
    
    printf("Nombre: %s\n",persona1.nombre);
     printf("Edad: %d\n",persona1.edad);
       printf("Altura: %.2f\n",persona1.altura);
    
    return 0;
}
