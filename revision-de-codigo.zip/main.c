/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdib.h>


int main()
{
    int a = 67;
    int b = 33;
    
    printf("la variable a vale %d\n", a);
     printf("y la b vale  %d\n", b);
      printf("el complemento de a es: %d\n", ~a);
       printf("el producto logico de a y b es: %d\n",a&b);
        printf("su suma logica es: %d\n",a|b);
         printf("su suma logica exclusiva es:  %d\n",a^b);
          printf("desplacemos a a la izquierda: %d\n",a<<1);
           printf("desplacemos a a la derecha: %d\n",a>>1);
    

    return 0;
}
