/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct Persona
{
    char nombre[10];
    float altura;
    int edad;
};

int main()
{
    struct Persona persona1[5];
    
    for (int i=0; i<5; i++){
        
    printf("¿ CUAL ES SU NOMBRE ? %d\n",i+1);
    scanf("%s",persona1[i].nombre);
    
    printf("¿ CUAL ES SU ALTURA ? %d\n",i+1);
    scanf("%f",&persona1[i].altura);
    
    printf("¿ CUAL ES SU EDAD ? %d\n",i+1);
    scanf("%d",&persona1[i].edad);
    }
    return 0;
}
