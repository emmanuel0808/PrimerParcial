/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

#include <stdlib.h>

 

int main(){

  int valor =5 ;

  int *p;

  int **pp;

  p=&valor;

  pp=&p;

  

  printf("Contenido en memoria: %d  Direccion de memoria: %p  Tipo de dato: int\n", valor, &valor );

  printf("Contenido en memoria: %p  Direccion de memoria: %p  Tipo de dato: int*\n",p,&p);

  printf("Contenido en memoria: %p  Direccion de memoria: %p  Tipo de dato: int**\n",pp,&pp);

  printf("\n\nEl valor al que apunta mi puntero a entero es: %d",*p);

}
